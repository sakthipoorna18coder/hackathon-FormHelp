import dns from 'node:dns/promises';
import net from 'node:net';

const pub = (msg, status = 400) => Object.assign(new Error(msg), { publicMessage: msg, status });

function isPrivate(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const l = ip.toLowerCase();
  return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80') || l.startsWith('::ffff:');
}

function htmlToText(html) {
  return html
    .replace(/<(script|style|noscript|svg)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<(input|select|textarea)\b([^>]*)>/gi, (_, tag, attrs) => {
      const g = n => (attrs.match(new RegExp(n + '\\s*=\\s*"([^"]*)"', 'i')) || [])[1];
      return ` [${tag} ${[g('type'), g('name'), g('placeholder'), g('aria-label')].filter(Boolean).join(' ')}] `;
    })
    .replace(/<\/(p|div|li|tr|h[1-6]|label|legend|option)>|<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
}

async function checkHost(u) {
  if (!['http:', 'https:'].includes(u.protocol)) throw pub('Only http or https links are supported.');
  let addrs;
  try { addrs = await dns.lookup(u.hostname, { all: true }); } catch { throw pub('The link could not be reached. Check the address.'); }
  if (!addrs.length || addrs.some(a => isPrivate(a.address))) throw pub('That address is not allowed.');
}

export async function fetchPageText(raw) {
  let u;
  try { u = new URL(raw); } catch { throw pub('The link is not valid.'); }
  // Follow up to 3 redirects, re-checking the address at every hop.
  for (let hop = 0; hop <= 3; hop++) {
    await checkHost(u);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 10000);
    try {
      const r = await fetch(u, { redirect: 'manual', signal: ctrl.signal, headers: {
        'user-agent': 'Mozilla/5.0 (compatible; FormMitra/1.0)', accept: 'text/html,text/plain;q=0.9,*/*;q=0.5' } });
      if ([301, 302, 303, 307, 308].includes(r.status)) {
        const loc = r.headers.get('location');
        if (!loc) throw pub('The page redirected without a destination.');
        u = new URL(loc, u);
        continue;
      }
      if (r.status === 401 || r.status === 403) throw pub('The website refused access. Please upload a photo or paste the text instead.');
      if (!r.ok) throw pub('The page could not be opened (status ' + r.status + '). Please upload a photo instead.');
      const ct = r.headers.get('content-type') || '';
      if (!/text\/(html|plain)/i.test(ct)) throw pub('Only web pages are supported (not PDFs). Please upload a photo instead.');
      const buf = await r.arrayBuffer();
      if (buf.byteLength > 2_000_000) throw pub('The page is too large.');
      const text = htmlToText(new TextDecoder().decode(buf));
      if (text.length < 40) throw pub('No readable form content found (the page may load its form with JavaScript). Please upload a photo or paste the text.');
      return text;
    } catch (e) {
      if (e.publicMessage) throw e;
      throw pub('The link could not be opened. Please upload a photo or paste the text instead.');
    } finally { clearTimeout(timer); }
  }
  throw pub('Too many redirects. Please upload a photo instead.');
}
