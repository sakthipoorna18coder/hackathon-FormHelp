export const SYSTEM_FORM = `You help people understand official forms. You only output JSON. You never copy personal data already written on a form. You never invent fields.`;
export const SYSTEM_ANSWER = `You interpret one spoken or typed answer for one form field. You only output JSON. You never guess missing information; when unsure you ask for clarification.`;

export const formPrompt = (language, text) => `Read the form ${text ? 'text below' : 'in the attached image'} and return ONLY this JSON:
{"title":"form title","fields":[{"label":"heading exactly as printed","help":"ONE short, simple sentence in ${language} explaining what to enter","type":"text|date|number|choice","options":["only when type is choice"]}]}
Rules: include only items the applicant must fill, in form order, at most 30. Use type "date" for dates and "number" for amounts. Write every "help" in ${language}.${text ? '\n\nFORM TEXT:\n' + text : ''}`;

export const answerPrompt = ({ language, field, spoken_answer, previous_value }) => `Field label: ${JSON.stringify(field.label)}
Field help: ${JSON.stringify(field.help)}
Field type: ${field.type}${field.options?.length ? '\nAllowed options: ' + JSON.stringify(field.options) : ''}
Previous value: ${JSON.stringify(previous_value ?? null)}
Person's answer (English, Tamil or Hindi; may be a correction such as "no, change it to ..."): ${JSON.stringify(spoken_answer)}
Return ONLY this JSON:
{"value":"final value (dates as DD/MM/YYYY, money as digits only, convert monthly to annual only if the field asks annual income)","message":"one short sentence in ${language} reading back what you understood and stating any conversion, e.g. 12000 per month is 144000 per year","needs_clarification":false}
If the answer is ambiguous, incomplete or not a valid value for the field, set needs_clarification to true, value to "", and make message a short question in ${language}.`;
