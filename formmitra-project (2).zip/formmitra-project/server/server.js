import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { SYSTEM_FORM, SYSTEM_ANSWER, formPrompt, answerPrompt } from './prompts.js';
import { fetchPageText } from './safeFetch.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '8mb' }));
// Privacy: no request logging middleware, no body logging, nothing written to disk.

const KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.MODEL || 'claude-sonnet-5-5';
const LANGS = ['English', 'Tamil', 'Hindi'];
const TYPES = ['text', 'date', 'number', 'choice'];
const str = (v, n) => String(v ?? '').slice(0, n);
const bad = (msg, status = 400) => Object.assign(new Error(msg), { publicMessage: msg, status });
const fail = (res, e) => {
  console.error('request failed:', e.status || 500); // status only, never content
  res.status(e.status || 500).json({ error: e.publicMessage || 'The request could not be completed. Please try again or enter answers manually.' });
};

async function callClaude(system, content) {
  if (!KEY) throw bad('The AI service is not configured on the server.', 503);
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: MODEL, max_tokens: 3000, system, messages: [{ role: 'user', content }] })
  });
  if (!r.ok) throw bad('The AI service is unavailable. Please enter answers manually.', 502);
  const j = await r.json();
  const text = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
  const m = text.replace(/```json|```/g, '').match(/\{[\s\S]*\}/);
  if (!m) throw bad('The AI response could not be understood.', 502);
  try { return JSON.parse(m[0]); } catch { throw bad('The AI response could not be understood.', 502); }
}

app.post('/api/analyze-form', async (req, res) => {
  try {
    const { language = 'English', imageBase64, mediaType = 'image/jpeg', url, text } = req.body || {};
    const lang = LANGS.includes(language) ? language : 'English';
    let content;
    if (imageBase64) {
      if (!/^image\/(jpeg|png|webp|gif)$/.test(mediaType)) throw bad('Unsupported image type.');
      content = [{ type: 'image', source: { type: 'base64', media_type: mediaType, data: imageBase64 } }, { type: 'text', text: formPrompt(lang) }];
    } else {
      const src = text ? str(text, 30000) : url ? (await fetchPageText(str(url, 2000))).slice(0, 30000) : '';
      if (!src) throw bad('Provide a photo, a link, or the form text.');
      content = formPrompt(lang, src);
    }
    const out = await callClaude(SYSTEM_FORM, content);
    const fields = (Array.isArray(out.fields) ? out.fields : []).slice(0, 30).map((f, i) => ({
      id: 'f' + (i + 1), label: str(f.label, 200), help: str(f.help, 300),
      type: TYPES.includes(f.type) ? f.type : 'text',
      options: f.type === 'choice' && Array.isArray(f.options) ? f.options.slice(0, 30).map(o => str(o, 100)) : undefined
    })).filter(f => f.label);
    if (!fields.length) throw bad('No form fields were found. Try a clearer photo or paste the text.', 422);
    res.json({ title: str(out.title, 200) || 'Form', fields });
  } catch (e) { fail(res, e); }
});

app.post('/api/interpret-answer', async (req, res) => {
  try {
    const { language = 'English', field, spoken_answer, previous_value = null } = req.body || {};
    if (!field || !spoken_answer) throw bad('Missing field or answer.');
    const f = { label: str(field.label, 200), help: str(field.help, 300), type: TYPES.includes(field.type) ? field.type : 'text',
      options: Array.isArray(field.options) ? field.options.slice(0, 30).map(o => str(o, 100)) : [] };
    // Data minimisation: only this field, the answer, and the previous value are sent.
    const out = await callClaude(SYSTEM_ANSWER, answerPrompt({
      language: LANGS.includes(language) ? language : 'English', field: f,
      spoken_answer: str(spoken_answer, 500), previous_value: previous_value == null ? null : str(previous_value, 200) }));
    const needs = !!out.needs_clarification || out.value === '' || out.value == null;
    res.json({ value: needs ? '' : str(out.value, 300), message: str(out.message, 400), needs_clarification: needs, needs_confirmation: !needs });
  } catch (e) { fail(res, e); }
});

app.get('/api/health', (_req, res) => res.json({ ok: true, ai: !!KEY }));
app.listen(process.env.PORT || 3001, () => console.log('FormMitra server running on port', process.env.PORT || 3001));
