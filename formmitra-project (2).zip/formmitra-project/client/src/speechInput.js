export const LANG_CODES = { English: 'en-IN', Tamil: 'ta-IN', Hindi: 'hi-IN' };
const SR = () => window.SpeechRecognition || window.webkitSpeechRecognition;
export const isSpeechSupported = () => !!SR();

// Starts recognition in the selected language. Returns a stop() function (or null if unsupported).
export function startListening({ language, onResult, onError, onEnd }) {
  const Rec = SR();
  if (!Rec) { onError('unsupported'); return null; }
  const rec = new Rec();
  rec.lang = LANG_CODES[language] || 'en-IN';
  rec.interimResults = false;
  rec.maxAlternatives = 1;
  rec.onresult = e => onResult(e.results[0][0].transcript);
  rec.onerror = e => onError(e.error);
  rec.onend = () => onEnd && onEnd();
  try { rec.start(); } catch { onError('busy'); return null; }
  return () => { try { rec.abort(); } catch { /* ignore */ } };
}
