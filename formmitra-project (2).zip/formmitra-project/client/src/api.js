async function post(path, body) {
  let r;
  try {
    r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  } catch { throw new Error('The service could not be reached.'); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'The request could not be completed.');
  return j;
}
export const analyzeForm = payload => post('/api/analyze-form', payload);
export const interpretAnswer = payload => post('/api/interpret-answer', payload);
