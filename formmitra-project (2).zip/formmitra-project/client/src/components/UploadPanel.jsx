import { useState } from 'react';

async function toJpegBase64(file) {
  const bm = await createImageBitmap(file);
  const s = Math.min(1, 1600 / Math.max(bm.width, bm.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bm.width * s); c.height = Math.round(bm.height * s);
  c.getContext('2d').drawImage(bm, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.85).split(',')[1];
}

export default function UploadPanel({ busy, onAnalyze, onSample }) {
  const [mode, setMode] = useState('photo');
  const [file, setFile] = useState(null);
  const [url, setUrl] = useState('');
  const [text, setText] = useState('');
  const [err, setErr] = useState('');

  const submit = async () => {
    setErr('');
    try {
      if (mode === 'photo') {
        if (!file) return setErr('Please select a photograph of the form.');
        onAnalyze({ imageBase64: await toJpegBase64(file), mediaType: 'image/jpeg' });
      } else if (mode === 'link') {
        if (!/^https?:\/\//i.test(url.trim())) return setErr('Enter a complete link beginning with http:// or https://');
        onAnalyze({ url: url.trim() });
      } else {
        if (text.trim().length < 20) return setErr('Please paste the form text.');
        onAnalyze({ text: text.trim() });
      }
    } catch { setErr('The image could not be opened. Please use a JPG or PNG file.'); }
  };

  return (
    <section className="panel">
      <h2><span className="step">Step 1</span> Submit the Form</h2>
      <p className="muted">Provide the form as a photograph, a web link, or pasted text. Use a blank form or fictional information only.</p>
      <div className="tabs" role="tablist">
        {[['photo', 'Photograph'], ['link', 'Web link'], ['text', 'Pasted text']].map(([k, l]) => (
          <button key={k} role="tab" aria-selected={mode === k} className={'tab' + (mode === k ? ' active' : '')} onClick={() => setMode(k)}>{l}</button>
        ))}
      </div>
      {mode === 'photo' && <input type="file" accept="image/*" aria-label="Form photograph" onChange={e => setFile(e.target.files[0] || null)} />}
      {mode === 'link' && <input type="url" placeholder="https://example.gov.in/application-form" aria-label="Form link" value={url} onChange={e => setUrl(e.target.value)} />}
      {mode === 'text' && <textarea rows="6" placeholder="Paste the text of the form here" aria-label="Form text" value={text} onChange={e => setText(e.target.value)} />}
      {err && <p className="field-error" role="alert" style={{ marginLeft: 0 }}>{err}</p>}
      <div className="actions">
        <button className="btn btn-primary" disabled={busy} onClick={submit}>{busy ? 'Reading the form…' : 'Analyse Form'}</button>
        <button className="btn" disabled={busy} onClick={onSample}>Use Sample Form</button>
      </div>
    </section>
  );
}
