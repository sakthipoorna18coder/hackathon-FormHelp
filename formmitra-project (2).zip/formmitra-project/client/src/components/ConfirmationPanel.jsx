import { useState } from 'react';
import VoiceButton from './VoiceButton.jsx';
import { T } from '../i18n.js';

export default function ConfirmationPanel({ pending, language, onYes, onCorrect, onCancel, onVoiceError }) {
  const [fixing, setFixing] = useState(!pending.value);
  const [text, setText] = useState('');
  const t = T[language] || T.English;
  const submit = () => { if (text.trim()) { onCorrect(text.trim()); setText(''); } };
  return (
    <aside className="sheet" role="dialog" aria-label="Confirm answer">
      <div className="sheet-in">
        <p className="sheet-field">{pending.field.label}</p>
        <p className="sheet-msg">{pending.message}</p>
        {pending.value && <p className="sheet-value">Interpreted value: <strong>{pending.value}</strong></p>}
        {!fixing && (
          <div className="actions">
            <button className="btn btn-primary" onClick={onYes}>{t.yes}</button>
            <button className="btn" onClick={() => setFixing(true)}>{t.no}</button>
          </div>
        )}
        {fixing && (
          <div className="actions">
            <input aria-label="Type the correct answer" placeholder="Speak or type the correct answer" value={text}
              onChange={e => setText(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} autoFocus />
            <VoiceButton language={language} onText={onCorrect} onError={onVoiceError} label="Speak correction" />
            <button className="btn btn-primary" onClick={submit}>Submit correction</button>
            <button className="btn" onClick={onCancel}>Cancel</button>
          </div>
        )}
      </div>
    </aside>
  );
}
