import { useEffect, useRef, useState } from 'react';
import { startListening } from '../speechInput.js';

export default function VoiceButton({ language, onText, onError, label = 'Speak answer' }) {
  const [on, setOn] = useState(false);
  const stop = useRef(null);
  useEffect(() => () => stop.current && stop.current(), []);
  const click = () => {
    if (on) { stop.current && stop.current(); setOn(false); return; }
    setOn(true);
    stop.current = startListening({
      language, onResult: onText,
      onError: e => { setOn(false); onError && onError(e); },
      onEnd: () => setOn(false)
    });
  };
  return (
    <button type="button" className={'btn' + (on ? ' listening' : '')} onClick={click} aria-pressed={on} aria-label={label}>
      {on ? 'Recording… (stop)' : 'Record Response'}
    </button>
  );
}
