import VoiceButton from './VoiceButton.jsx';
import { speakText } from '../speechOutput.js';

export default function FieldCard({ index, field, value, error, language, onChange, onVoice, onVoiceError }) {
  const id = 'in_' + field.id;
  return (
    <section className={'field' + (error ? ' invalid' : '')} id={'card_' + field.id}>
      <div className="field-head">
        <span className="field-no">{index + 1}</span>
        <div>
          <label htmlFor={id} className="field-label">{field.label}</label>
          <p className="field-help">{field.help}</p>
        </div>
      </div>
      <div className="field-controls">
        {field.type === 'choice' && field.options?.length ? (
          <select id={id} value={value} onChange={e => onChange(e.target.value)}>
            <option value="">Select…</option>
            {field.options.map(o => <option key={o}>{o}</option>)}
          </select>
        ) : (
          <input id={id} type={field.type === 'number' ? 'number' : 'text'} min={field.type === 'number' ? 0 : undefined}
            inputMode={field.type === 'number' ? 'numeric' : undefined} placeholder={field.type === 'date' ? 'DD/MM/YYYY' : ''}
            autoComplete="off" value={value} onChange={e => onChange(e.target.value)} />
        )}
        <button type="button" className="btn" onClick={() => speakText(field.label + '. ' + field.help, language)}>Read Aloud</button>
        <VoiceButton language={language} onText={onVoice} onError={onVoiceError} />
      </div>
      {error && <p className="field-error" role="alert">{error}</p>}
    </section>
  );
}
