import { useState } from 'react';
import { validateValue } from '../validate.js';
import { speakText } from '../speechOutput.js';

export default function FinalReview({ form, answers, language, onEdit, onBack }) {
  const [done, setDone] = useState(false);
  const rows = form.fields.map(f => ({ f, v: answers[f.id] ?? '', e: validateValue(f, answers[f.id]) }));
  const problems = rows.filter(r => r.e).length;
  const finish = () => { setDone(true); speakText('Review complete. Nothing has been submitted.', language); };
  return (
    <section className="panel">
      <h2><span className="step">Step 3</span> Final review</h2>
      {problems > 0 && <p className="notice warn" role="alert">{problems} item(s) require attention before completion.</p>}
      <table className="review">
        <thead><tr><th>Item</th><th>Response</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {rows.map(({ f, v, e }) => (
            <tr key={f.id} className={e ? 'miss' : ''}>
              <td>{f.label}</td><td>{v || '—'}</td><td>{e || 'Complete'}</td>
              <td><button className="btn btn-small" onClick={() => onEdit(f.id)}>Edit</button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="actions">
        <button className="btn" onClick={onBack}>Return to form</button>
        <button className="btn btn-primary" disabled={problems > 0} onClick={finish}>Confirm and complete</button>
      </div>
      {done && <p className="notice ok" role="status">Review complete. This is a demonstration; nothing was submitted or stored. Select “Clear &amp; Exit” to remove all entries.</p>}
    </section>
  );
}
