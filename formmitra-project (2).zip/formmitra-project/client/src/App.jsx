import { useRef, useState } from 'react';
import UploadPanel from './components/UploadPanel.jsx';
import FieldCard from './components/FieldCard.jsx';
import ConfirmationPanel from './components/ConfirmationPanel.jsx';
import FinalReview from './components/FinalReview.jsx';
import { analyzeForm, interpretAnswer } from './api.js';
import { validateValue } from './validate.js';
import { speakText, stopSpeaking, hasVoiceFor, voiceLabel } from './speechOutput.js';
import { sampleForm, localize } from './sampleForm.js';
import { localInterpret } from './localInterpret.js';
import { T } from './i18n.js';

const LANGUAGES = ['English', 'Tamil', 'Hindi'];
const VOICE_ERRORS = {
  unsupported: 'Voice input is not supported in this browser. Please type your answer.',
  'not-allowed': 'Microphone permission was denied. Please type your answer.',
  'no-speech': 'No speech was detected. Please try again or type your answer.',
  'language-not-supported': 'Voice recognition is not available for this language on this device. Please type your answer.',
  busy: 'The microphone is busy. Please try again.'
};

export default function App() {
  const [language, setLanguage] = useState('English');
  const [form, setForm] = useState(null);
  const [answers, setAnswers] = useState({});
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [pending, setPending] = useState(null);
  const [reviewing, setReviewing] = useState(false);
  const source = useRef(null); // last submitted form source, kept in memory only
  const isSample = useRef(false);

  const say = m => setNotice(m);
  const voiceError = e => say(VOICE_ERRORS[e] || 'Voice recognition failed. Please type your answer.');

  const analyze = async (payload, lang = language) => {
    setBusy(true); say('Reading the form. This may take a few seconds…');
    try {
      const r = await analyzeForm({ ...payload, language: lang });
      source.current = payload; isSample.current = false;
      setForm(r); setReviewing(false); setPending(null);
      say(r.fields.length + ' items found. Select “Read Aloud” to hear an explanation, or “Record Response” to answer.');
    } catch (e) { say(e.message + ' You may use the sample form to try the service.'); }
    setBusy(false);
  };
  const useSample = () => { isSample.current = true; source.current = null; setForm(localize(sampleForm, language)); setAnswers({}); setReviewing(false); say('Sample form loaded.'); };
  const reexplain = () => {
    if (isSample.current) setForm(localize(sampleForm, language));
    else if (source.current) analyze(source.current, language);
  };

  const setAnswer = (f, v) => {
    if (f.type === 'number' && Number(v) < 0) return say('Negative values are not permitted.');
    setAnswers(a => ({ ...a, [f.id]: v }));
  };

  const showPending = (f, value, message) => {
    setPending({ field: f, value, message });
    speakText(message + (value ? ' ' + T[language].q : ''), language);
    say('');
  };
  // Order: instant local rules (dates, numbers, choices) -> AI service if reachable -> safe fallback.
  const handleSpoken = async (f, text) => {
    const local = localInterpret(f, text, language);
    if (local && !local.clarify) return showPending(f, local.value, local.message);
    say('Interpreting your answer…');
    try {
      const r = await interpretAnswer({ language, field: f, spoken_answer: text, previous_value: answers[f.id] ?? null });
      if (r.needs_clarification || !r.value) showPending(f, '', r.message || local?.clarify || '');
      else showPending(f, r.value, r.message || r.value);
    } catch {
      if (local?.clarify) showPending(f, '', local.clarify);
      else showPending(f, text, T[language].raw);
    }
  };
  const confirmYes = () => {
    setAnswer(pending.field, pending.value);
    setPending(null); say(T[language].saved); speakText(T[language].saved, language);
  };

  const filled = form ? form.fields.filter(f => !validateValue(f, answers[f.id])).length : 0;
  const clearAll = () => {
    stopSpeaking(); source.current = null; isSample.current = false;
    setForm(null); setAnswers({}); setPending(null); setReviewing(false); say('All entries have been cleared. Nothing was stored.');
    window.scrollTo(0, 0);
  };
  const edit = id => { setReviewing(false); setTimeout(() => document.getElementById('card_' + id)?.scrollIntoView({ block: 'center' }), 50); };

  return (
    <>
      <div className="strip">Demonstration system. Not affiliated with any Government department. Use fictional information only.</div>
      <header className="masthead">
        <div className="wrap">
          <h1>FormMitra</h1>
          <p className="tag">Form Assistance Facility</p>
          <p className="tag2">படிவ மித்ரா &nbsp;|&nbsp; फ़ॉर्म मित्र</p>
        </div>
      </header>
      <main className="wrap">
        <div className="toolbar">
          <label htmlFor="lang">Language for explanation and voice</label>
          <select id="lang" value={language} onChange={e => {
            setLanguage(e.target.value);
            const lg = e.target.value;
            if (isSample.current) setForm(localize(sampleForm, lg));
            say(hasVoiceFor(lg) ? 'Read-aloud voice: ' + voiceLabel(lg) + '.' : 'No ' + (lg === 'English' ? 'Indian English' : lg) + ' voice found on this device, so a default voice will read the text. For Tamil and Hindi voices, use Microsoft Edge (it includes online Tamil and Hindi voices) or install the language voice pack in Windows Settings > Time & language > Speech.' + (form && !isSample.current ? ' Press "Explain again" to get explanations in ' + lg + '.' : ''));
          }}>
            {LANGUAGES.map(l => <option key={l}>{l}</option>)}
          </select>
          {form && <button className="btn" onClick={reexplain} disabled={busy}>Explain again in {language}</button>}
          <button className="btn btn-danger" onClick={clearAll}>Clear &amp; Exit</button>
        </div>

        <p className="notice" role="status" aria-live="polite">{notice || 'Notice: Please read the instructions under each heading. Responses are not stored.'}</p>

        {!form && <UploadPanel busy={busy} onAnalyze={analyze} onSample={useSample} />}

        {form && !reviewing && (
          <section className="panel">
            <h2><span className="step">Step 2</span> Application: {form.title}</h2>
            <div className="progress" role="progressbar" aria-valuemin="0" aria-valuemax={form.fields.length} aria-valuenow={filled}>
              <i style={{ width: (filled / form.fields.length * 100) + '%' }} />
            </div>
            <p className="muted">{filled} of {form.fields.length} items completed</p>
            <div className="actions">
              <button className="btn" onClick={() => speakText(form.fields.map(f => f.label + '. ' + f.help).join(' '), language)}>Read All Headings Aloud</button>
            </div>
            {form.fields.map((f, i) => (
              <FieldCard key={f.id} index={i} field={f} language={language} value={answers[f.id] ?? ''}
                error={answers[f.id] ? validateValue(f, answers[f.id]) : ''}
                onChange={v => setAnswer(f, v)} onVoice={t => handleSpoken(f, t)} onVoiceError={voiceError} />
            ))}
            <div className="actions"><button className="btn btn-primary" onClick={() => setReviewing(true)}>Review Responses</button></div>
          </section>
        )}

        {form && reviewing && <FinalReview form={form} answers={answers} language={language} onEdit={edit} onBack={() => setReviewing(false)} />}

        <footer className="privacy">
          <strong>Privacy statement.</strong> Responses are held in this page's memory only and are removed by “Clear &amp; Exit”. No database,
          browser storage or history is used, and nothing is submitted to any portal. The form image or text and individual answers are sent
          to an AI service for interpretation; voice recognition is performed by your browser, which may use its vendor's cloud service.
          Do not enter real personal information in this demonstration.
        </footer>
      </main>
      {pending && <ConfirmationPanel key={pending.field.id + pending.value} pending={pending} language={language} onYes={confirmYes}
        onCorrect={t => handleSpoken(pending.field, t)} onCancel={() => setPending(null)} onVoiceError={voiceError} />}
    </>
  );
}
