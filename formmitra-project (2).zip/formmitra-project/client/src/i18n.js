export const T = {
  English: { yes: 'Yes, correct', no: 'No, change it', q: 'Is this correct?', saved: 'Answer recorded.', raw: 'Automatic interpretation is unavailable. Use this text as entered?' },
  Hindi: { yes: 'हाँ, सही है', no: 'नहीं, बदलें', q: 'क्या यह सही है?', saved: 'उत्तर दर्ज हो गया।', raw: 'स्वचालित व्याख्या उपलब्ध नहीं है। क्या इस पाठ को जैसा है वैसा उपयोग करें?' },
  Tamil: { yes: 'ஆம், சரி', no: 'இல்லை, மாற்று', q: 'இது சரியா?', saved: 'பதில் பதிவு செய்யப்பட்டது.', raw: 'தானியங்கி விளக்கம் கிடைக்கவில்லை. இந்த உரையை அப்படியே பயன்படுத்தலாமா?' }
};
