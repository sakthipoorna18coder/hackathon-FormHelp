export function validateValue(field, value) {
  const v = String(value ?? '').trim();
  if (v === '') return 'Required';
  if (field.type === 'number') {
    if (isNaN(Number(v))) return 'Enter a number';
    if (Number(v) < 0) return 'Value cannot be negative';
  }
  if (field.type === 'date') {
    const m = v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!m) return 'Use the format DD/MM/YYYY';
    const d = new Date(+m[3], +m[2] - 1, +m[1]);
    if (d.getMonth() !== +m[2] - 1 || d.getDate() !== +m[1]) return 'Not a valid date';
    if (d > new Date()) return 'Date cannot be in the future';
  }
  if (field.type === 'choice' && field.options?.length && !field.options.includes(v)) return 'Select one of the listed options';
  return '';
}
