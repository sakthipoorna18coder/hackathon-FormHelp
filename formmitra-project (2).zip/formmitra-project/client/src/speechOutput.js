import { LANG_CODES } from './speechInput.js';

export const canSpeak = () => 'speechSynthesis' in window;

// Preferred Indian voices by name, per language (installed voices vary by device).
const PREFERRED = {
  English: ['Neerja', 'Heera', 'Ravi', 'Prabhat', 'India'],
  Tamil: ['Pallavi', 'Valluvar', 'Tamil', 'தமிழ்'],
  Hindi: ['Swara', 'Madhur', 'Kalpana', 'Hemant', 'Hindi', 'हिन्दी']
};

// Chooses an Indian-locale voice (en-IN / ta-IN / hi-IN). Returns null when none is installed.
export function pickVoice(language) {
  if (!canSpeak()) return null;
  const code = (LANG_CODES[language] || 'en-IN').toLowerCase();
  const all = speechSynthesis.getVoices();
  const exact = all.filter(v => v.lang.replace('_', '-').toLowerCase() === code);
  const pool = exact.length ? exact : language === 'English' ? [] : all.filter(v => v.lang.toLowerCase().startsWith(code.slice(0, 2)));
  if (!pool.length) return null;
  const score = v => (PREFERRED[language] || []).reduce((s, n, i) => s + (v.name.includes(n) ? 10 - i : 0), 0)
    + (/natural|online|neural/i.test(v.name) ? 5 : 0) + (v.localService ? 0 : 1);
  return [...pool].sort((a, b) => score(b) - score(a))[0];
}

export const hasVoiceFor = language => !!pickVoice(language);
export const voiceLabel = language => { const v = pickVoice(language); return v ? v.name + ' (' + v.lang + ')' : ''; };

// Voices load asynchronously in some browsers; touching the list early helps them populate.
if (canSpeak()) { speechSynthesis.getVoices(); speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices(); }

export function speakText(text, language = 'English') {
  if (!canSpeak() || !text) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = LANG_CODES[language] || 'en-IN';
  const v = pickVoice(language);
  if (v) u.voice = v;
  u.rate = 0.92; // slightly slower for clarity
  speechSynthesis.speak(u);
}
export const stopSpeaking = () => { if (canSpeak()) speechSynthesis.cancel(); };
