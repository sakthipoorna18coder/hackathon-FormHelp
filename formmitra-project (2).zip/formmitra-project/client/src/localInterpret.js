// Rule-based interpretation that runs in the browser (no AI needed) for dates, numbers and choices.
import { LANG_CODES } from './speechInput.js';
import { validateValue } from './validate.js';

const S = {
  English: {
    got: (l, v) => `I understood ${l} as ${v}.`, conv: (m, y) => `₹${m} per month is ₹${y} per year.`,
    badDate: 'I could not read a valid date. Please say the day, month and year, for example 15 March 2005.',
    badNum: 'I could not understand the number. Please say it again, for example twelve thousand.',
    period: 'Is that amount per month or per year? Please say it again with "per month" or "per year".',
    both: 'Did you mean per month or per year?', many: 'More than one option was heard. Please say only one.',
    pick: o => `Please choose one of: ${o}.`
  },
  Hindi: {
    got: (l, v) => `मैंने ${l} को ${v} समझा।`, conv: (m, y) => `₹${m} प्रति माह यानी ₹${y} प्रति वर्ष।`,
    badDate: 'मैं सही तिथि नहीं समझ सका। कृपया दिन, महीना और वर्ष बोलें, जैसे 15 मार्च 2005।',
    badNum: 'मैं संख्या नहीं समझ सका। कृपया दोबारा बोलें, जैसे बारह हज़ार।',
    period: 'क्या यह राशि प्रति माह है या प्रति वर्ष? कृपया "प्रति माह" या "प्रति वर्ष" के साथ दोबारा बोलें।',
    both: 'क्या आपका मतलब प्रति माह है या प्रति वर्ष?', many: 'एक से अधिक विकल्प सुने गए। कृपया केवल एक बोलें।',
    pick: o => `कृपया इनमें से एक चुनें: ${o}।`
  },
  Tamil: {
    got: (l, v) => `${l} என்பதை ${v} என்று புரிந்துகொண்டேன்.`, conv: (m, y) => `மாதம் ₹${m} என்பது ஆண்டுக்கு ₹${y}.`,
    badDate: 'சரியான தேதியைப் புரிந்துகொள்ள முடியவில்லை. நாள், மாதம், ஆண்டு சொல்லுங்கள், எ.கா. 15 மார்ச் 2005.',
    badNum: 'எண்ணைப் புரிந்துகொள்ள முடியவில்லை. மீண்டும் சொல்லுங்கள், எ.கா. பன்னிரண்டாயிரம்.',
    period: 'இந்தத் தொகை மாதத்திற்கா ஆண்டுக்கா? "மாதம்" அல்லது "ஆண்டு" என்று சேர்த்துச் சொல்லுங்கள்.',
    both: 'மாதமா அல்லது ஆண்டா?', many: 'ஒன்றுக்கு மேற்பட்ட விருப்பங்கள் கேட்டன. ஒன்றை மட்டும் சொல்லுங்கள்.',
    pick: o => `இவற்றில் ஒன்றைத் தேர்ந்தெடுக்கவும்: ${o}.`
  }
};

const norm = t => t.replace(/[०-९]/g, c => '०१२३४५६७८९'.indexOf(c)).replace(/[௦-௯]/g, c => '௦௧௨௩௪௫௬௭௮௯'.indexOf(c)).replace(/(\d),(?=\d)/g, '$1');

export const stripCorrection = t => t.replace(
  /^\s*(?:(?:no|nope|nahi|nahin)(?![a-z])|नहीं|नही|இல்லை)[\s,.:-]*(?:please\s*)?(?:(?:change(?: it)?(?: to)?|it'?s|make it|correct(?: it)?(?: to)?)(?![a-z])|बदलकर|மாற்று)?[\s,.:-]*/i, '').trim();

const W = { zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90 };
function wordsToNumber(t) {
  let total = 0, cur = 0, seen = false;
  for (const w of t.split(/[\s-]+/)) {
    if (w in W) { cur += W[w]; seen = true; }
    else if (w === 'hundred') { cur = (cur || 1) * 100; seen = true; }
    else if (w === 'thousand' || w === 'hazaar') { total += (cur || 1) * 1e3; cur = 0; seen = true; }
    else if (w === 'lakh' || w === 'lakhs' || w === 'lac') { total += (cur || 1) * 1e5; cur = 0; seen = true; }
    else if (w === 'crore') { total += (cur || 1) * 1e7; cur = 0; seen = true; }
  }
  return seen ? total + cur : null;
}
function parseNumber(lo) {
  const m = lo.match(/(\d+(?:\.\d+)?)/);
  const mult = /lakh|lac|लाख|லட்சம்|இலட்சம்/.test(lo) ? 1e5 : /crore|करोड़|करोड|கோடி/.test(lo) ? 1e7 : /thousand|hazaar|हज़ार|हजार|ஆயிரம்|\bk\b/.test(lo) ? 1e3 : 1;
  const n = m ? parseFloat(m[1]) * mult : wordsToNumber(lo);
  return n == null || isNaN(n) ? null : n;
}

const MONTHS = [
  ['jan', 'जनवरी', 'ஜனவரி'], ['feb', 'फरवरी', 'फ़रवरी', 'பிப்ரவரி'], ['mar', 'मार्च', 'மார்ச்'], ['apr', 'अप्रैल', 'ஏப்ரல்'],
  ['may', 'मई', 'மே'], ['jun', 'जून', 'ஜூன்'], ['jul', 'जुलाई', 'ஜூலை'], ['aug', 'अगस्त', 'ஆகஸ்ட்'],
  ['sep', 'सितंबर', 'सितम्बर', 'செப்டம்பர்'], ['oct', 'अक्टूबर', 'அக்டோபர்'], ['nov', 'नवंबर', 'नवम्बर', 'நவம்பர்'], ['dec', 'दिसंबर', 'दिसम्बर', 'டிசம்பர்']
];
const monthIndex = w => { const l = w.toLowerCase(); return MONTHS.findIndex(a => a.some(n => /^[a-z]+$/.test(n) ? l.startsWith(n) : l.startsWith(n))) + 1; };

function parseDate(lo) {
  let d, m, y, x;
  if ((x = lo.match(/(\d{1,2})[\/.\-\s](\d{1,2})[\/.\-\s](\d{4})/))) { d = +x[1]; m = +x[2]; y = +x[3]; }
  else if ((x = lo.match(/(\d{4})-(\d{1,2})-(\d{1,2})/))) { y = +x[1]; m = +x[2]; d = +x[3]; }
  else if ((x = lo.match(/(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?(\S+?)[,\s]+(\d{4})/))) { d = +x[1]; m = monthIndex(x[2]); y = +x[3]; }
  else if ((x = lo.match(/([^\d\s]+)\s+(\d{1,2})(?:st|nd|rd|th)?[,\s]+(\d{4})/))) { m = monthIndex(x[1]); d = +x[2]; y = +x[3]; }
  if (!y || !m) return null;
  const dt = new Date(y, m - 1, d);
  if (dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
  return dt;
}

// Returns {value,message} on success, {clarify} when the answer could not be understood, or null if not handled here.
export function localInterpret(field, raw, language) {
  const s = S[language] || S.English;
  const code = LANG_CODES[language] || 'en-IN';
  const t = norm(stripCorrection(raw)).trim(), lo = t.toLowerCase();
  if (!t) return null;

  if (field.type === 'date') {
    const dt = parseDate(lo);
    if (!dt) return { clarify: s.badDate };
    const v = String(dt.getDate()).padStart(2, '0') + '/' + String(dt.getMonth() + 1).padStart(2, '0') + '/' + dt.getFullYear();
    const err = validateValue(field, v);
    if (err) return { clarify: err + '. ' + s.badDate };
    return { value: v, message: s.got(field.label, dt.toLocaleDateString(code, { day: 'numeric', month: 'long', year: 'numeric' })) };
  }

  if (field.type === 'number') {
    const n = parseNumber(lo);
    if (n == null) return { clarify: s.badNum };
    const monthly = /month|monthly|माह|महीन|மாதம்/.test(lo), yearly = /year|annual|साल|वर्ष|वार्षिक|ஆண்டு|வருடம்/.test(lo);
    const annualField = /annual|yearly|वार्षिक|ஆண்டு/i.test(field.label + ' ' + field.help);
    const fmt = x => Math.round(x).toLocaleString('en-IN');
    if (monthly && yearly) return { clarify: s.both };
    if (monthly && annualField) return { value: String(Math.round(n * 12)), message: s.conv(fmt(n), fmt(n * 12)) };
    if (annualField && !monthly && !yearly && n < 30000) return { clarify: s.period };
    return { value: String(Math.round(n)), message: s.got(field.label, '₹' + fmt(n)) };
  }

  if (field.type === 'choice' && field.options?.length) {
    const ALIAS = { general: ['सामान्य', 'பொது'], minority: ['अल्पसंख्यक', 'சிறுபான்மை'] };
    const tokens = lo.replace(/\./g, '').split(/\s+/);
    const hits = field.options.filter(o => {
      const ol = o.toLowerCase();
      return ol.length <= 3 ? tokens.includes(ol) : lo.includes(ol) || (ALIAS[ol] || []).some(a => lo.includes(a));
    });
    if (hits.length === 1) return { value: hits[0], message: s.got(field.label, hits[0]) };
    return { clarify: hits.length > 1 ? s.many : s.pick(field.options.join(', ')) };
  }
  return null;
}
