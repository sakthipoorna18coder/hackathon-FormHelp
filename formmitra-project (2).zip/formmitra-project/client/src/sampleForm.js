// Fictional demonstration form. Illustrative only; not a real scheme.
const h = (English, Tamil, Hindi) => ({ English, Tamil, Hindi });
export const sampleForm = {
  title: 'Sample Scholarship Application (illustrative)',
  fields: [
    { id: 's1', label: 'Applicant Name', type: 'text', help: h('Enter the full name of the student as in school records.', 'பள்ளிப் பதிவேட்டில் உள்ளபடி மாணவரின் முழுப் பெயரை உள்ளிடவும்.', 'स्कूल रिकॉर्ड के अनुसार छात्र का पूरा नाम लिखें।') },
    { id: 's2', label: 'Date of Birth', type: 'date', help: h('Enter the date of birth as DD/MM/YYYY.', 'பிறந்த தேதியை DD/MM/YYYY வடிவில் உள்ளிடவும்.', 'जन्म तिथि DD/MM/YYYY रूप में लिखें।') },
    { id: 's3', label: 'Annual Family Income (₹)', type: 'number', help: h('Total yearly income of the family in rupees.', 'குடும்பத்தின் மொத்த ஆண்டு வருமானம் ரூபாயில்.', 'परिवार की कुल वार्षिक आय रुपये में।') },
    { id: 's4', label: 'Scholarship Category', type: 'choice', options: ['SC', 'ST', 'OBC', 'Minority', 'EWS', 'General'], help: h('Choose the category you belong to.', 'நீங்கள் சேரும் வகையைத் தேர்ந்தெடுக்கவும்.', 'अपनी श्रेणी चुनें।') }
  ]
};
export const localize = (form, language) => ({ ...form, fields: form.fields.map(f => ({ ...f, help: typeof f.help === 'string' ? f.help : f.help[language] })) });
