# FormMitra — Form Assistance Service

Upload a photo of a form, paste a link, or paste its text. FormMitra reads each heading, gives a short
explanation in English, Tamil or Hindi, then takes your answers by voice or keyboard, reads them back
for confirmation, and shows a final review. Prototype for demonstration with FICTIONAL data only.

## Structure
- `server/`  Express API (keeps the API key off the browser)
  - `server.js` endpoints `/api/analyze-form`, `/api/interpret-answer`
  - `prompts.js` model instructions · `safeFetch.js` link fetching with address safeguards
- `client/`  React + Vite frontend
  - `src/speechInput.js`, `src/speechOutput.js` browser speech recognition / read-aloud
  - `src/components/` UploadPanel, FieldCard, VoiceButton, ConfirmationPanel, FinalReview

## Run (Node 18+)
```
cd server
cp .env.example .env        # add ANTHROPIC_API_KEY
npm install
npm start                   # http://localhost:3001

cd ../client                # second terminal
npm install
npm run dev                 # http://localhost:5173  (use Chrome for voice)
```
No API key? Use "Use sample form" in the app: voice, read-aloud, confirmation and review still work,
answers are accepted as typed/spoken without AI interpretation.

## Privacy design
- No database, no localStorage/sessionStorage/cookies, no history. Form data lives in React state and
  is cleared by "Clear & Exit".
- Server does not log request or response bodies and writes nothing to disk.
- Only the uploaded image/page text, or the single field and answer being interpreted, is sent to the AI.
- A backend proxy protects the API key; it does NOT stop the AI provider from retaining data.
  Verify the provider's retention and training policies before using any real information.
- Browser voice recognition may use the browser vendor's cloud service (Chrome does).
- Nothing is submitted to any government portal.

## Limitations
- Links: only public HTML pages. Pages built with JavaScript, behind login, or PDFs are not supported;
  upload a photo or paste the text instead. Private/internal addresses are blocked, but a hosted
  deployment should add a network-level egress policy as well.
- Tamil/Hindi recognition depends on browser and device support; typing always works.
- AI output can be wrong: always check the confirmation before accepting.
